package anomalies;

public class FlightPair {

    private long actual;
    private int all;


    public FlightPair(long actual, int all) {
        this.actual = actual;
        this.all = all;
    }

    public <VO> FlightPair(Long val1, VO val2) {
    }

    public long getActual() {
        return actual;
    }

    public void setActual(long actual) {
        this.actual = actual;
    }

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}
