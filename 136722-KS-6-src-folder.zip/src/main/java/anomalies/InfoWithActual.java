package anomalies;

import java.time.Instant;

public class InfoWithActual extends Info {
    
    private long actual;
    
    public InfoWithActual(Instant startTime, Instant endTime, long count, String code) {
        super(startTime, endTime, count, code);
    }

    public InfoWithActual(long actual, Info info) {
        super(info);
        this.actual = actual;
    }

    public long getActual() {
        return actual;
    }

    public void setActual(long actual) {
        this.actual = actual;
    }
}
