package anomalies;

import java.time.Instant;

public class Info {

    private Instant startTime;
    private Instant endTime;
    private long count;
    private String code;

    public Info (Instant startTime, Instant endTime, long count, String code) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.count = count;
        this.code = code;
    }

    public Info (Info info) {
        this.startTime = info.getStartTime();
        this.endTime = info.getEndTime();
        this.count = info.getCount();
        this.code = info.getCode();
    }


    public Instant getStartTime() {
        return startTime;
    }

    public void setStartTime(Instant startTime) {
        this.startTime = startTime;
    }

    public Instant getEndTime() {
        return endTime;
    }

    public void setEndTime(Instant endTime) {
        this.endTime = endTime;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
